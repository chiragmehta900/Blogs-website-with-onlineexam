<div class="main-content">
            <!-- Banner Section Start -->
            <div id="rs-banner" class="rs-banner style1">
                <div class="container">
                    <div class="banner-content text-center">
                        <h1 class="banner-title capitalize wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="3000ms">Education during COVID-19 moving towards e-learning</h1>
                        <div class="desc mb-35 wow wow fadeInRight" data-wow-delay="900ms" data-wow-duration="3000ms">Every act of conscious learning requires the willingness to <br>suffer an injury to one’s self-esteem during COVID-19.</div>
                        <div class="banner-btn wow fadeInUp" data-wow-delay="1500ms" data-wow-duration="2000ms">
                            <a class="readon banner-style" href="#">Get Started Now</a>
                        </div>
                    </div>
                </div>
            </div>
			<!-- Banner Section End -->
</div>